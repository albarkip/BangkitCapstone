package com.thecoolture.batikdetectionapp.data

data class BatikDetailEntity(
    var name: String,
    var origin: String,
    var meaning: String,
    var short_desc: String?,
    var history: String?
)
